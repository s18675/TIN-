function silnia(x) {
    wynik = 1;
    while (n > 0) {
          wynik = wynik * x ;
          x -- ;
        }
document.write(wynik);
}
silnia(6);
