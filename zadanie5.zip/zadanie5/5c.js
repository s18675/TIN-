const tab = [1, 2, 3, 4, 5, 6];
function wartosc(x) {
  const tablica = (Math.max.apply(Math, x) -1);
  return tablica;
}
document.write(wartosc(tab));
