var max = 0;
var tab = [1,2,3,4,5,6,7,8,9,10];
for (var i = 0; i < tab.length; i++) {
    if (max <= tab[i]) {
        max = tab[i];
    }
}
console.log("Najwieksza liczba z danej tablicy tablicy to:", max);
