var cyfra1 = 10;
var cyfra2 = 4;
var cyfra3 = 12;

function jaka(x) {
  if (x < Math.max(cyfra2, cyfra3) && x > Matk.min(cyfra2, cyfra3))
  return ("Cyfra pierwsza jest między liczbą drugą a liczbą trzecią");
  else
  return ("Cyfra pierwsza nie jest między liczbą drugą a liczbą trzecią");
}
document.write(jaka(liczba1));
