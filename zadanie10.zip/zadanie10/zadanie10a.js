const port = 3050;
const hostname = "127.0.0.2";
var express= require ('express');
var app = express();

app.get('/hello', function (req, res) {
  res.send('Hello world!');
})

app.listen(port, hostname, function() {
  console.log('Wczytywanie adresu strony 127.0.0.2 na porcie 3050');
});
