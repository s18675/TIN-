function student (imie, nazwisko, nr_indeksu, oceny = []){
this.imie = imie;
this.nazwisko = nazwisko;
this.nr_indeksu = nr_indeksu;
this.oceny = oceny;
}
let uczen = new student("Sylwia", "Matczuk", 18675 + " " + [5, 5, 5, 4, 5, 4, 5]);
document. write(uczen.imie + uczen.nazwisko + uczen.nr_indeksu + uczen.oceny);
