var myObject = new Object();
        myObject.myString = "Sylwia";
        myObject.myString = "Matczuk";
        myObject.myString = "s18675";

        myObject.myFunction = function(){
                return this.myString;
            };
        myObject.myFunction(); 
