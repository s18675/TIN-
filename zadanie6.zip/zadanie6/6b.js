var student1 = {
  imie:"Sylwia",
  nazwisko: "Matczuk",
  numer_indeksu: "s18675"
};

console.console.log(student1.imie + " " + student1.nazwisko + " " + student1.numer_indeksu + " ");
