const tab = ["Polskie", "Górnictwo", "Naftowe", "i", "Gazownictwo"];
function tablica(tab) {
  return(tab);
}
alert (tablica(tab).join(""));
