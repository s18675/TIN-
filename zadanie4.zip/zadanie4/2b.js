var x;
  alert ("Podaj numer szafki");

  if(x % 3 == 1) {
    prompt("szafka jest na górze");
  }
  else if(x % 3 == 2) {
    prompt("szafka jest na srodku");
  }
  else {
    prompt("szafka jest na dole");
  }
