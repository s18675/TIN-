var x;
x = "hello word";
console.log(x);
