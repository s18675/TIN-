function readTable (tab) {
  for (var i = 0; i < tab.length; i++) {
    console.log(tab[i]);
  }
};
var mark = [
  "NIKE", //indeks 0
  "ADiDAS", //indeks 1
  "REEBOK", //indeks 2
  "PUMA", //indeks 3
  "NEW BALANCE", //indeks 4
];

readTable(mark);
