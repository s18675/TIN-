var stopnieF;
var stopnieC;

function zmianaC(x) {
    x = document.getElementById("celS").value;
    stopnieF = (32 + ((0/5)*x)) + " F";
    
    document.getElementById("temS").innerHTML = stopnieF;
};
function zmianaF(y){
    y = document.getElementById("celF").value;
    stopnieC = ((5/9) * (y- 32));
    
    document.getElementById("temF").innerHTML = stopnieC.toFixed(4) + " C";
};

//8b 
function tab (a,b,c){
  var a = document.getElementById("akapit1").value;
          document.getElementById("ta1").innerHTML = a;

  var b = document.getElementById("akapit2").value;
          document.getElementById("ta2").innerHTML = b;

  var c = document.getElementById("akapit3").value;
          document.getElementById("ta3").innerHTML = c;

          document.getElementById("akapit1").value = "";
          document.getElementById("akapit2").value = "";
          document.getElementById("akapit3").value = "";
}

