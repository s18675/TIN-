var evt;
function onlyNumberKey(evt) {
	var ASCIICode = (evt.which) ? evt.which : event.keyCode
	if (ASCIICode > 31 && (ASCIICode <48 || ASCIICode >57))
		return false;
	return true;
}
function walidacja() {
	var haslo = "admin";
	var usupelnione = false;
	var uzu1 = 0;
	var formularz = document.forms[0];
	var dane = [];
	
	if (formularz.pass.value == haslo) {
		uzupelnione = true;
		uzu1 = uzu1 + 1;
	} else if (formularz.pass.value != haslo){
		uzupelnione = false;
		alert("Wprowadz dane - haslo: admin");
	}
	if (formularz.telefon.value == !dane || dane<0 || dane >9){
		uzupelnione = false;
		alert("Brakuje odpowiednich danych! Wpisz wyłacznie numery.");
	}
	else {
		uzupelnione = true;
		uzu1 = uzu1 +1;
		
	}
	if (uzu1 == 2)
		formularz.submit();
    
    ///8 
    function tab (a,b,c){
  var a = document.getElementById("akapit1").value;
          document.getElementById("ta1").innerHTML = a;

  var b = document.getElementById("akapit2").value;
          document.getElementById("ta2").innerHTML = b;

  var c = document.getElementById("akapit3").value;
          document.getElementById("ta3").innerHTML = c;

          document.getElementById("akapit1").value = "";
          document.getElementById("akapit2").value = "";
          document.getElementById("akapit3").value = "";
}

};